<html>
<head>
    <title>Nuova Richiesta di Sponsorizzazione</title>
</head>
<body>
    <h1>Nuova Richiesta di Sponsorizzazione</h1>
    <form action="nuova_richiesta.php" method="POST">
        Prodotto: <input type="text" name="prodotto"><br>
        Target: <input type="text" name="target"><br>
        Social:
        <select name="social">
        <?php
        $conn = mysqli_connect("localhost", "root", "", "esame test");
        $result = mysqli_query($conn, "SELECT * FROM social;");
        while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            echo "<option value='" . $row['nome_social'] . "'>" . $row['nome_social'] . "</option>";
        }
        ?>
        </select><br>
        Tipologia comunicatore ricercata:
        <select name="tipologia">
        <?php
        $result = mysqli_query($conn, "SELECT * FROM tipologia;");
        while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            echo "<option value='" . $row['nome_tipologia'] . "'>" . $row['nome_tipologia'] . "</option>";
        }
        ?>
        </select><br>
        Budget: <input type="text" name="budget"><br>
        Periodo inizio: <input type="date" name="periodo_inizio"><br>
        Periodo fine: <input type="date" name="periodo_fine"><br>
        Scadenza candidature: <input type="date" name="data_scadenza"><br><br>
        <input type="submit" value="Inserisci Richiesta">
    </form>
</body>
</html>