<?php
session_start();
$id_comunicatore = $_SESSION['id_comunicatore'];
$nome = $_POST["nome"];
$cognome = $_POST["cognome"];
$data_di_nascita = $_POST["data_di_nascita"];
$num_tel = $_POST["num_tel"];
$foto = $_POST["foto"];
$mail = $_POST["mail"];
$link_social_personale = $_POST["link_social_personale"];
$user = $_POST["user"];
$pw = password_hash($_POST["pw"], PASSWORD_DEFAULT);

$conn = mysqli_connect("localhost", "root", "", "esame test");
$query = "UPDATE comunicatore SET nome='$nome', cognome='$cognome', data_di_nascita='$data_di_nascita',
          num_tel='$num_tel', foto='$foto', mail='$mail', link_social_personale='$link_social_personale',
          username='$user', pw='$pw' WHERE id_comunicatore='$id_comunicatore';";
mysqli_query($conn, $query);
header("location: dashboard.php");
exit();
?>