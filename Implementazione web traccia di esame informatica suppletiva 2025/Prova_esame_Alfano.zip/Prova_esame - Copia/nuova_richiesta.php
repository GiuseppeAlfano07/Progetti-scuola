<?php
session_start();
$id_azienda = $_SESSION['id_azienda'];
$prodotto = $_POST["prodotto"];
$target = $_POST["target"];
$social = $_POST["social"];
$tipologia = $_POST["tipologia"];
$budget = $_POST["budget"];
$periodo_inizio = $_POST["periodo_inizio"];
$periodo_fine = $_POST["periodo_fine"];
$data_scadenza = $_POST["data_scadenza"];
$data_inserimento = date('Y-m-d H:i:s');

$conn = mysqli_connect("localhost", "root", "", "esame test");

$query = "SELECT * FROM social WHERE nome_social='$social';";
$result = mysqli_query($conn, $query);
$num = mysqli_num_rows($result);

if($num == 0) {
    echo "Social non valido, torna indietro e inserisci un social esistente";
    exit();
}
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
$id_social = $row['id_social'];

$query = "SELECT * FROM tipologia WHERE nome_tipologia='$tipologia';";
$result = mysqli_query($conn, $query);
$num = mysqli_num_rows($result);

if($num == 0) {
    echo "Tipologia non valida, torna indietro e inserisci una tipologia esistente";
    exit();
}
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
$id_tipologia = $row['id_tipologia'];

$query = "INSERT INTO richiesta (data_inserimento, prodotto, target, budget, data_scadenza, periodo_inizio, periodo_fine, id_azienda, id_social, id_tipologia)
          VALUES ('$data_inserimento','$prodotto','$target','$budget','$data_scadenza','$periodo_inizio','$periodo_fine','$id_azienda','$id_social','$id_tipologia');";
mysqli_query($conn, $query);
header("location: dashboard.php");
exit();
?>