<?php
$id_richiesta = $_POST["id_richiesta"];
$conn = mysqli_connect("localhost", "root", "", "esame test");
$query = "DELETE FROM richiesta WHERE id_richiesta='$id_richiesta';";
$result = mysqli_query($conn, $query);
$num = mysqli_affected_rows($conn);

if($num != 0) {
    echo "Richiesta cancellata con successo";
    header("location: dashboard.php");
    exit();
} else {
    echo "Richiesta inesistente";
    header("location: dashboard.php");
    exit();
}
?>