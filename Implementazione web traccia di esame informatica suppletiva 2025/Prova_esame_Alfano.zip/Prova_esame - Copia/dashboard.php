<html>
<head>
    <title>Dashboard</title>
</head>
<body>
<?php
session_start();
$tipo = $_SESSION['tipo'];

if($tipo == "comunicatore") {
    $id_comunicatore = $_SESSION['id_comunicatore'];
    $conn = mysqli_connect("localhost", "root", "", "esame test");
    $query = "SELECT * FROM richiesta WHERE data_scadenza >= NOW();";
    $result = mysqli_query($conn, $query);

    echo "<h1>Richieste di Sponsorizzazione Disponibili</h1>";

    if($result) {
        while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            echo "Prodotto: " . $row['prodotto'] . "<br>";
            echo "Target: " . $row['target'] . "<br>";
            echo "Budget: " . $row['budget'] . "<br>";
            echo "Scadenza candidature: " . $row['data_scadenza'] . "<br>";
            echo "Periodo: " . $row['periodo_inizio'] . " - " . $row['periodo_fine'] . "<br>";

            echo "<form action='candidatura.php' method='POST'>";
            echo "<input type='hidden' name='id_richiesta' value='" . $row['id_richiesta'] . "'>";
            echo "<input type='submit' value='CANDIDATI'>";
            echo "</form><br>";
        }
    }
    echo "<a href='modifica_comunicatore_grafico.php'>Modifica i tuoi dati</a><br><br>";
    echo "<a href='logout.php'>Logout</a>";
}

else {
    $id_azienda = $_SESSION['id_azienda'];
    $conn = mysqli_connect("localhost", "root", "", "esame test");
    $query = "SELECT * FROM richiesta WHERE id_azienda='$id_azienda';";
    $result = mysqli_query($conn, $query);

    echo "<h1>Le tue Richieste di Sponsorizzazione</h1>";

    if($result) {
        while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            echo "Prodotto: " . $row['prodotto'] . "<br>";
            echo "Target: " . $row['target'] . "<br>";
            echo "Budget: " . $row['budget'] . "<br>";
            echo "Scadenza candidature: " . $row['data_scadenza'] . "<br>";
            echo "Periodo: " . $row['periodo_inizio'] . " - " . $row['periodo_fine'] . "<br>";

            echo "<form action='cancellazione.php' method='POST'>";
            echo "<input type='hidden' name='id_richiesta' value='" . $row['id_richiesta'] . "'>";
            echo "<input type='submit' value='CANCELLA RICHIESTA'>";
            echo "</form>";

            if($row['data_scadenza'] < date('Y-m-d')) {
                echo "<form action='vista_candidature.php' method='POST'>";
                echo "<input type='hidden' name='id_richiesta' value='" . $row['id_richiesta'] . "'>";
                echo "<input type='submit' value='VEDI CANDIDATURE'>";
                echo "</form>";
            }

            echo "<br>";
        }
    }
    echo "<a href='nuova_richiesta_grafico.php'>Inserisci nuova richiesta</a><br><br>";
    echo "<a href='logout.php'>Logout</a>";
}
?>
</body>
</html>