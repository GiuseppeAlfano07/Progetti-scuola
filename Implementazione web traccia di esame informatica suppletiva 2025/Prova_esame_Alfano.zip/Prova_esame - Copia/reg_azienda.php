<?php
$ragione_sociale = $_POST["ragione_sociale"];
$logo = $_POST["logo"];
$sito_web = $_POST["sito_web"];
$sede = $_POST["sede"];
$mail = $_POST["mail"];
$num_tel = $_POST["num_tel"];
$settore = $_POST["settore"];
$user = $_POST["user"];
$pw = password_hash($_POST["pw"], PASSWORD_DEFAULT);

$conn = mysqli_connect("localhost", "root", "", "esame test");

$query = "SELECT * FROM settore WHERE nome_settore='$settore';";
$result = mysqli_query($conn, $query);
$num = mysqli_num_rows($result);

if($num != 0) {
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
    $id_settore = $row['id_settore'];
    $query = "INSERT INTO azienda (ragione_sociale, logo, sito_web, sede, mail, num_tel, id_settore, username, pw)
              VALUES ('$ragione_sociale','$logo','$sito_web','$sede','$mail','$num_tel','$id_settore','$user','$pw');";
    mysqli_query($conn, $query);
    header("location: index.html");
    exit();
} else {
    echo "Settore non valido, torna indietro e inserisci un settore esistente";
}
?>