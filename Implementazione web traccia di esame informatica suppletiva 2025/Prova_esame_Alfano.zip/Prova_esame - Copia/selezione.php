<?php
$id_candidatura = $_POST["id_candidatura"];
$id_richiesta = $_POST["id_richiesta"];

$conn = mysqli_connect("localhost", "root", "", "esame test");
$query = "UPDATE candidatura SET selezionato='SI' WHERE id_candidatura='$id_candidatura';";
mysqli_query($conn, $query);
header("location: dashboard.php");
exit();
?>