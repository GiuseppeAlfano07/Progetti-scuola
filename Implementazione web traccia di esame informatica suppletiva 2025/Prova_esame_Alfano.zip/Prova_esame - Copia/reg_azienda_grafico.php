<html>
<head>
    <title>Registrazione Azienda</title>
</head>
<body>
    <h1>Registrazione Azienda</h1>
    <form action="reg_azienda.php" method="POST">
        Ragione Sociale: <input type="text" name="ragione_sociale"><br>
        Logo (url): <input type="text" name="logo"><br>
        Sito Web: <input type="text" name="sito_web"><br>
        Sede: <input type="text" name="sede"><br>
        Mail: <input type="text" name="mail"><br>
        Telefono: <input type="text" name="num_tel"><br>
        Settore:
        <select name="settore">
        <?php
        $conn = mysqli_connect("localhost", "root", "", "esame test");
        $result = mysqli_query($conn, "SELECT * FROM settore;");
        while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            echo "<option value='" . $row['nome_settore'] . "'>" . $row['nome_settore'] . "</option>";
        }
        ?>
        </select><br>
        Username: <input type="text" name="user"><br>
        Password: <input type="password" name="pw"><br><br>
        <input type="submit" value="Registra Azienda">
    </form>
</body>
</html>