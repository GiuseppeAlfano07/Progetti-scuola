<?php
$nome = $_POST["nome"];
$cognome = $_POST["cognome"];
$data_di_nascita = $_POST["data_di_nascita"];
$num_tel = $_POST["num_tel"];
$foto = $_POST["foto"];
$mail = $_POST["mail"];
$link_social_personale = $_POST["link_social_personale"];
$tipologia = $_POST["tipologia"];
$user = $_POST["user"];
$pw = password_hash($_POST["pw"], PASSWORD_DEFAULT);

$conn = mysqli_connect("localhost", "root", "", "esame test");

$query = "SELECT * FROM tipologia WHERE nome_tipologia='$tipologia';";
$result = mysqli_query($conn, $query);
$num = mysqli_num_rows($result);

if($num != 0) {
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
    $id_tipologia = $row['id_tipologia'];
    $query = "INSERT INTO comunicatore (nome, cognome, data_di_nascita, num_tel, foto, mail, link_social_personale, id_tipologia, username, pw)
              VALUES ('$nome','$cognome','$data_di_nascita','$num_tel','$foto','$mail','$link_social_personale','$id_tipologia','$user','$pw');";
    mysqli_query($conn, $query);
    header("location: index.html");
    exit();
} else {
    echo "Tipologia non valida, torna indietro e inserisci una tipologia esistente";
}
?>