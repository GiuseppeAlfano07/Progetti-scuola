<html>
<head>
    <title>Registrazione Comunicatore</title>
</head>
<body>
    <h1>Registrazione Comunicatore</h1>
    <form action="reg_comunicatore.php" method="POST">
        Nome: <input type="text" name="nome"><br>
        Cognome: <input type="text" name="cognome"><br>
        Data di nascita: <input type="date" name="data_di_nascita"><br>
        Telefono: <input type="text" name="num_tel"><br>
        Foto (url): <input type="text" name="foto"><br>
        Mail: <input type="text" name="mail"><br>
        Link Social Personale: <input type="text" name="link_social_personale"><br>
        Tipologia:
        <select name="tipologia">
        <?php
        $conn = mysqli_connect("localhost", "root", "", "esame test");
        $result = mysqli_query($conn, "SELECT * FROM tipologia;");
        while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            echo "<option value='" . $row['nome_tipologia'] . "'>" . $row['nome_tipologia'] . "</option>";
        }
        ?>
        </select><br>
        Username: <input type="text" name="user"><br>
        Password: <input type="password" name="pw"><br><br>
        <input type="submit" value="Registra Comunicatore">
    </form>
</body>
</html>