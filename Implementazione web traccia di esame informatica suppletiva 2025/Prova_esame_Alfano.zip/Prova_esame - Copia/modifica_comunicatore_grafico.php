<html>
<head>
    <title>Modifica Dati Comunicatore</title>
</head>
<body>
    <h1>Modifica i tuoi dati</h1>
    <form action="modifica_comunicatore.php" method="POST">
        Nuovo nome: <input type="text" name="nome"><br>
        Nuovo cognome: <input type="text" name="cognome"><br>
        Nuova data di nascita: <input type="date" name="data_di_nascita"><br>
        Nuovo telefono: <input type="text" name="num_tel"><br>
        Nuova foto (url): <input type="text" name="foto"><br>
        Nuova mail: <input type="text" name="mail"><br>
        Nuovo link social personale: <input type="text" name="link_social_personale"><br>
        Nuova tipologia:
        <select name="tipologia">
        <?php
        $conn = mysqli_connect("localhost", "root", "", "esame test");
        $result = mysqli_query($conn, "SELECT * FROM tipologia;");
        while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            echo "<option value='" . $row['nome_tipologia'] . "'>" . $row['nome_tipologia'] . "</option>";
        }
        ?>
        </select><br>
        Nuovo username: <input type="text" name="user"><br>
        Nuova password: <input type="password" name="pw"><br><br>
        <input type="submit" value="Aggiorna dati">
    </form>
</body>
</html>