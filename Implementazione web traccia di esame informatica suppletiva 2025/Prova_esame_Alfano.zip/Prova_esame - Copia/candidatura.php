<?php
session_start();
$id_comunicatore = $_SESSION['id_comunicatore'];
$id_richiesta = $_POST["id_richiesta"];

$conn = mysqli_connect("localhost", "root", "", "esame test");

$query = "SELECT * FROM candidatura WHERE id_comunicatore='$id_comunicatore' AND id_richiesta='$id_richiesta';";
$result = mysqli_query($conn, $query);
$num = mysqli_num_rows($result);

if($num != 0) {
    echo "Ti sei già candidato per questa richiesta";

	header( "refresh:1; url=dashboard.php" );
    exit();
}

$query = "INSERT INTO candidatura (id_comunicatore, id_richiesta) VALUES ('$id_comunicatore','$id_richiesta');";
mysqli_query($conn, $query);
header("location: dashboard.php");
exit();
?>