<html>
<head>
    <title>Vista Candidature</title>
</head>
<body>
<?php
$id_richiesta = $_POST["id_richiesta"];
$conn = mysqli_connect("localhost", "root", "", "esame test");

$query = "SELECT candidatura.id_candidatura, candidatura.selezionato,
                 comunicatore.nome, comunicatore.cognome, comunicatore.mail,
                 comunicatore.num_tel, comunicatore.link_social_personale
          FROM candidatura
          JOIN comunicatore ON candidatura.id_comunicatore = comunicatore.id_comunicatore
          WHERE candidatura.id_richiesta='$id_richiesta';";
$result = mysqli_query($conn, $query);

echo "<h1>Candidature ricevute</h1>";

if($result) {
    while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        echo "Nome: " . $row['nome'] . " " . $row['cognome'] . "<br>";
        echo "Mail: " . $row['mail'] . "<br>";
        echo "Telefono: " . $row['num_tel'] . "<br>";
        echo "Social: " . $row['link_social_personale'] . "<br>";
        echo "Selezionato: " . $row['selezionato'] . "<br>";

        if($row['selezionato'] == 'NO') {
            echo "<form action='selezione.php' method='POST'>";
            echo "<input type='hidden' name='id_candidatura' value='" . $row['id_candidatura'] . "'>";
            echo "<input type='hidden' name='id_richiesta' value='$id_richiesta'>";
            echo "<input type='submit' value='SELEZIONA QUESTO COMUNICATORE'>";
            echo "</form>";
        }

        echo "<br>";
    }
}
?>
</body>
</html>