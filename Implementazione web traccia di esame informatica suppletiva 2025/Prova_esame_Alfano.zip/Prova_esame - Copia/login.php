<?php
session_start();
$user = $_POST["user"];
$pw = $_POST["pw"];
$tipo = $_POST["tipo"];

$conn = mysqli_connect("localhost", "root", "", "esame test");

if($tipo == "azienda") {
    $query = "SELECT * FROM azienda WHERE username='$user';";
    $result = mysqli_query($conn, $query);
    $num = mysqli_num_rows($result);
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);

    if($num != 0 && password_verify($pw, $row['pw'])) {
        $_SESSION['username'] = $user;
        $_SESSION['tipo'] = "azienda";
        $_SESSION['id_azienda'] = $row['id_azienda'];
        header("location: dashboard.php");
        exit();
    } else {
        header("location: index.html");
        exit();
    }
}

if($tipo == "comunicatore") {
    $query = "SELECT * FROM comunicatore WHERE username='$user';";
    $result = mysqli_query($conn, $query);
    $num = mysqli_num_rows($result);
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);

    if($num != 0 && password_verify($pw, $row['pw'])) {
        $_SESSION['username'] = $user;
        $_SESSION['tipo'] = "comunicatore";
        $_SESSION['id_comunicatore'] = $row['id_comunicatore'];
        header("location: dashboard.php");
        exit();
    } else {
        header("location: index.html");
        exit();
    }
}
?>