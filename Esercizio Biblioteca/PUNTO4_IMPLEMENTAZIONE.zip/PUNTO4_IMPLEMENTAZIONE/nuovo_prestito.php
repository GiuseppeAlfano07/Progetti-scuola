<?php
session_start();
//VERIFICA SE L'UTENTE È LOGGATO
if(!isset($_SESSION['id_utente'])) {
    header("location: index.html");
    exit();
}
//VERIFICA SE L'UTENTE È AMMINISTRATORE
if($_SESSION['flag'] != 0) {
    header("location: dashboard.php");
    exit();
}
$id_libro = $_POST["id_libro"];
$cf = $_POST["cf"];
$data_inizio = $_POST["data_inizio"];
$data_fine = $_POST["data_fine"];

$conn = mysqli_connect("localhost", "root", "", "biblioteca");

// CERCA UTENTE TRAMITE CODICE FISCALE
$query = "SELECT * FROM utenti WHERE cf='$cf';";
$result = mysqli_query($conn, $query);
$num = mysqli_num_rows($result);

if($num == 0) {
    echo "Utente non trovato";
    header("refresh:2; url=dashboard.php");
    exit();
}

$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
$id_utente = $row['id_utente'];

// CREA IL PRESTITO
$query = "INSERT INTO prestiti (id_utente, id_libro, data_inizio, data_fine, stato) VALUES ('$id_utente','$id_libro','$data_inizio','$data_fine','IN_PRESTITO');";
mysqli_query($conn, $query);

// SEGNA IL LIBRO COME NON DISPONIBILE
$query = "UPDATE libri SET disponibile='NO' WHERE id_libro='$id_libro';";
mysqli_query($conn, $query);
$num = mysqli_affected_rows($conn);

if($num != 0) {
    echo "Prestito registrato con successo";
    header("refresh:2; url=dashboard.php");
    exit();
} else {
    echo "Errore durante la registrazione del prestito";
    header("refresh:2; url=dashboard.php");
    exit();
}
?>
