<?php
session_start();
//VERIFICA SE L'UTENTE È LOGGATO
if(!isset($_SESSION['id_utente'])) {
    header("location: index.html");
    exit();
}
$id_utente = $_SESSION['id_utente'];
$nome = $_POST["nome"];
$cognome = $_POST["cognome"];
$cf = $_POST["cf"];
$email = $_POST["email"];
$user = $_POST["user"];
$pw = password_hash($_POST["pw"], PASSWORD_DEFAULT);

$conn = mysqli_connect("localhost", "root", "", "biblioteca");
$query = "UPDATE utenti SET nome='$nome', cognome='$cognome', cf='$cf', email='$email', username='$user', password='$pw' WHERE id_utente='$id_utente';";
mysqli_query($conn, $query);
$num = mysqli_affected_rows($conn);

if($num != 0) {
    echo "Dati aggiornati con successo";
    header("refresh:2; url=dashboard.php");
    exit();
} else {
    echo "Errore durante l'aggiornamento";
    header("refresh:2; url=dashboard.php");
    exit();
}
?>
