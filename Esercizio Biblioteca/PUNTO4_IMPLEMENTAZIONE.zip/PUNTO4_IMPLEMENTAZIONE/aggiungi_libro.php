<?php
session_start();
//VERIFICA CHE L'UTENTE SIA LOGGATO
if(!isset($_SESSION['id_utente'])) {
    header("location: index.html");
    exit();
}
//VERIFICA CHE L'UTENTE SIA ADMIN
if($_SESSION['flag'] != 0) {
    header("location: dashboard.php");
    exit();
}
$titolo = $_POST["titolo"];
$autore = $_POST["autore"];
$editore = $_POST["editore"];
$prezzo = $_POST["prezzo"];
$isbn = $_POST["isbn"];
$n_pagine = $_POST["n_pagine"];
$genere = $_POST["genere"];

$conn = mysqli_connect("localhost", "root", "", "biblioteca");
$query = "INSERT INTO libri (titolo, autore, editore, prezzo, isbn, n_pagine, genere) VALUES ('$titolo','$autore','$editore','$prezzo','$isbn','$n_pagine','$genere');";
mysqli_query($conn, $query);
$num = mysqli_affected_rows($conn);

if($num != 0) {
    echo "Libro aggiunto con successo";
    header("refresh:2; url=gestione_libri.php");
    exit();
} else {
    echo "Errore durante l'inserimento";
    header("refresh:2; url=gestione_libri.php");
    exit();
}
?>
