<?php
session_start();
// CONTROLLA CHE L'UTENTE SIA LOGGATO
if(!isset($_SESSION['id_utente'])) {
    header("location: index.html");
    exit();
}
$id_utente = $_SESSION['id_utente'];
$id_libro = $_POST["id_libro"];
$giorni_richiesti = $_POST["giorni_richiesti"];

$conn = mysqli_connect("localhost", "root", "", "biblioteca");

// CONTROLLA CHE IL LIBRO SIA ANCORA DISPONIBILE
$query = "SELECT * FROM libri WHERE id_libro='$id_libro' AND disponibile='SI';";
$result = mysqli_query($conn, $query);
$num = mysqli_num_rows($result);

if($num == 0) {
    echo "Libro non disponibile";
    header("refresh:2; url=miei_prestiti.php");
    exit();
}

// CREA IL PRESTITO IN ATTESA
$query = "INSERT INTO prestiti (id_utente, id_libro, giorni_richiesti, stato) VALUES ('$id_utente','$id_libro','$giorni_richiesti','IN_ATTESA');";
mysqli_query($conn, $query);

// SEGNA IL LIBRO COME NON DISPONIBILE
$query = "UPDATE libri SET disponibile='NO' WHERE id_libro='$id_libro';";
mysqli_query($conn, $query);

echo "Richiesta inviata con successo";
header("refresh:2; url=miei_prestiti.php");
exit();
?>
