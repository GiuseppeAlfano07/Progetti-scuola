<?php
session_start();
//VERIFICA CHE L'UTENTE SIA LOGGATO
if(!isset($_SESSION['id_utente'])) {
    header("location: index.html");
    exit();
}
//VERIFICA CHE L'UTENTE SIA UN ADMIN
if($_SESSION['flag'] != 0) {
    header("location: dashboard.php");
    exit();
}
$id_libro = $_POST["id_libro"];
$titolo = $_POST["titolo"];
$autore = $_POST["autore"];
$editore = $_POST["editore"];
$prezzo = $_POST["prezzo"];
$isbn = $_POST["isbn"];
$n_pagine = $_POST["n_pagine"];
$genere = $_POST["genere"];

$conn = mysqli_connect("localhost", "root", "", "biblioteca");
$query = "UPDATE libri SET titolo='$titolo', autore='$autore', editore='$editore', prezzo='$prezzo', isbn='$isbn', n_pagine='$n_pagine', genere='$genere' WHERE id_libro='$id_libro';";
mysqli_query($conn, $query);
$num = mysqli_affected_rows($conn);

if($num != 0) {
    echo "Libro modificato con successo";
    header("refresh:2; url=gestione_libri.php");
    exit();
} else {
    echo "Errore durante la modifica";
    header("refresh:2; url=gestione_libri.php");
    exit();
}
?>
