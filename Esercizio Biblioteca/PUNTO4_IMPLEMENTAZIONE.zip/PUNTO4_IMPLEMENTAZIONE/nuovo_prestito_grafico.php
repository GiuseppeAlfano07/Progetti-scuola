<?php
session_start();
//VERIFICA SE L'UTENTE È LOGGATO
if(!isset($_SESSION['id_utente'])) {
    header("location: index.html");
    exit();
}
//VERIFICA SE L'UTENTE È AMMINISTRATORE
if($_SESSION['flag'] != 0) {
    header("location: dashboard.php");
    exit();
}
$id_libro = $_POST["id_libro"];
?>
<html>
<head>
    <title>BiblioHub — Nuovo Prestito</title>
    <!--LINK PICO CSS E FONT-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <style>
        :root { --pico-font-size: 14px; --pico-font-family: "Poppins", sans-serif; }
        main { max-width: 800px; }
    </style>
</head>
<body>
<main class="container">
    <!--LOGO, DASHBOARD, LOGOUT-->
    <nav><ul><li><svg width="200" height="46" viewBox="0 0 260 60" xmlns="http://www.w3.org/2000/svg"><rect x="0" y="0" width="260" height="60" rx="30" fill="#1a1a2e"/><g transform="rotate(-12, 48, 30)"><rect x="24" y="8" width="18" height="30" rx="2" fill="#4A90D9"/><line x1="28" y1="15" x2="38" y2="15" stroke="white" stroke-width="1" stroke-opacity="0.5"/><line x1="28" y1="20" x2="38" y2="20" stroke="white" stroke-width="1" stroke-opacity="0.5"/><line x1="28" y1="25" x2="38" y2="25" stroke="white" stroke-width="1" stroke-opacity="0.5"/></g><g transform="rotate(0, 58, 30)"><rect x="44" y="4" width="22" height="38" rx="2" fill="#f0f0f0"/><rect x="44" y="4" width="5" height="38" rx="2" fill="#d0d0d0"/><line x1="53" y1="13" x2="62" y2="13" stroke="#999" stroke-width="1"/><line x1="53" y1="19" x2="62" y2="19" stroke="#999" stroke-width="1"/><line x1="53" y1="25" x2="62" y2="25" stroke="#999" stroke-width="1"/><line x1="53" y1="31" x2="62" y2="31" stroke="#999" stroke-width="1"/></g><g transform="rotate(10, 74, 30)"><rect x="64" y="10" width="18" height="28" rx="2" fill="#E8734A"/><line x1="68" y1="17" x2="78" y2="17" stroke="white" stroke-width="1" stroke-opacity="0.5"/><line x1="68" y1="22" x2="78" y2="22" stroke="white" stroke-width="1" stroke-opacity="0.5"/><line x1="68" y1="27" x2="78" y2="27" stroke="white" stroke-width="1" stroke-opacity="0.5"/></g><text x="92" y="38" font-family="Georgia, serif" font-size="22" font-weight="700" fill="white">Biblio<tspan fill="#E8734A">Hub</tspan></text></svg></li></ul><ul><li><a href="gestione_libri.php" class="secondary">← Dashboard</a></li><li><a href="logout.php" class="secondary">Logout</a></li></ul></nav>
    <h1>Nuovo Prestito</h1>
    <form action="nuovo_prestito.php" method="POST">
        <input type="hidden" name="id_libro" value="<?php echo $id_libro; ?>">
        Codice Fiscale utente<input type="text" name="cf">
        Data inizio<input type="date" name="data_inizio">
        Data fine<input type="date" name="data_fine">
        <button type="submit">Registra Prestito</button>
    </form>
</main>
</body>
</html>