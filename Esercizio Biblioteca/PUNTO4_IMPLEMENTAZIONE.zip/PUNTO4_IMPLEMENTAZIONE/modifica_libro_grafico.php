<?php
session_start();
//VERIFICA CHE L'UTENTE SIA LOGGATO
if(!isset($_SESSION['id_utente'])) {
    header("location: index.html");
    exit();
}
//VERIFICA CHE L'UTENTE SIA UN ADMIN
if($_SESSION['flag'] != 0) {
    header("location: dashboard.php");
    exit();
}
$id_libro = $_POST["id_libro"];
$conn = mysqli_connect("localhost", "root", "", "biblioteca");
$query = "SELECT * FROM libri WHERE id_libro='$id_libro';";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
?>
<html>
<head>
    <title>BiblioHub — Modifica Libro</title>
    <!--LINK A PICO CSS E AL FONT-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap">
    <style>
        :root { --pico-font-size: 14px; --pico-font-family: "Poppins", sans-serif; }
        main { max-width: 800px; }
    </style>
</head>
<body>
<main class="container">
    <!--LOGO,DASHBOARD E LOGOUT-->
    <nav><ul><li><svg width="200" height="46" viewBox="0 0 260 60" xmlns="http://www.w3.org/2000/svg"><rect x="0" y="0" width="260" height="60" rx="30" fill="#1a1a2e"/><g transform="rotate(-12, 48, 30)"><rect x="24" y="8" width="18" height="30" rx="2" fill="#4A90D9"/><line x1="28" y1="15" x2="38" y2="15" stroke="white" stroke-width="1" stroke-opacity="0.5"/><line x1="28" y1="20" x2="38" y2="20" stroke="white" stroke-width="1" stroke-opacity="0.5"/><line x1="28" y1="25" x2="38" y2="25" stroke="white" stroke-width="1" stroke-opacity="0.5"/></g><g transform="rotate(0, 58, 30)"><rect x="44" y="4" width="22" height="38" rx="2" fill="#f0f0f0"/><rect x="44" y="4" width="5" height="38" rx="2" fill="#d0d0d0"/><line x1="53" y1="13" x2="62" y2="13" stroke="#999" stroke-width="1"/><line x1="53" y1="19" x2="62" y2="19" stroke="#999" stroke-width="1"/><line x1="53" y1="25" x2="62" y2="25" stroke="#999" stroke-width="1"/><line x1="53" y1="31" x2="62" y2="31" stroke="#999" stroke-width="1"/></g><g transform="rotate(10, 74, 30)"><rect x="64" y="10" width="18" height="28" rx="2" fill="#E8734A"/><line x1="68" y1="17" x2="78" y2="17" stroke="white" stroke-width="1" stroke-opacity="0.5"/><line x1="68" y1="22" x2="78" y2="22" stroke="white" stroke-width="1" stroke-opacity="0.5"/><line x1="68" y1="27" x2="78" y2="27" stroke="white" stroke-width="1" stroke-opacity="0.5"/></g><text x="92" y="38" font-family="Georgia, serif" font-size="22" font-weight="700" fill="white">Biblio<tspan fill="#E8734A">Hub</tspan></text></svg></li></ul><ul><li><a href="gestione_libri.php" class="secondary">← Dashboard</a></li><li><a href="logout.php" class="secondary">Logout</a></li></ul></nav>
    <h1>Modifica Libro</h1>
    <form action="modifica_libro.php" method="POST">
        <input type="hidden" name="id_libro" value="<?php echo $row['id_libro']; ?>">
        Titolo<input type="text" name="titolo" value="<?php echo $row['titolo']; ?>">
        Autore<input type="text" name="autore" value="<?php echo $row['autore']; ?>">
        Editore<input type="text" name="editore" value="<?php echo $row['editore']; ?>">
        Prezzo<input type="text" name="prezzo" value="<?php echo $row['prezzo']; ?>">
        ISBN<input type="text" name="isbn" value="<?php echo $row['isbn']; ?>">
        Numero pagine<input type="number" name="n_pagine" value="<?php echo $row['n_pagine']; ?>">
        Genere<input type="text" name="genere" value="<?php echo $row['genere']; ?>">
        <button type="submit">Salva modifiche</button>
    </form>
</main>
</body>
</html>