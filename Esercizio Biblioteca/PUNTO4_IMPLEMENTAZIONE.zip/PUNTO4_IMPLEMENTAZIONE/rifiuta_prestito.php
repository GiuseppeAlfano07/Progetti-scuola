<?php
session_start();
//VERIFICA CHE L'UTENTE SIA LOGGATO
if(!isset($_SESSION['id_utente'])) {
    header("location: index.html");
    exit();
}
//VERIFICA CHE L'UTENTE SIA AMMINISTRATORE
if($_SESSION['flag'] != 0) {
    header("location: dashboard.php");
    exit();
}
$id_prestito = $_POST["id_prestito"];
$id_libro = $_POST["id_libro"];
$motivazione = $_POST["motivazione"];

$conn = mysqli_connect("localhost", "root", "", "biblioteca");

// AGGIORNA STATO PRESTITO E MOTIVAZIONE
$query = "UPDATE prestiti SET stato='RIFIUTATO', motivazione_rifiuto='$motivazione' WHERE id_prestito='$id_prestito';";
mysqli_query($conn, $query);

// SEGNA IL LIBRO COME DISPONIBILE
$query = "UPDATE libri SET disponibile='SI' WHERE id_libro='$id_libro';";
mysqli_query($conn, $query);
$num = mysqli_affected_rows($conn);

if($num != 0) {
    echo "Prestito rifiutato con successo";
    header("refresh:2; url=richieste.php");
    exit();
} else {
    echo "Errore durante il rifiuto del prestito";
    header("refresh:2; url=richieste.php");
    exit();
}
?>
