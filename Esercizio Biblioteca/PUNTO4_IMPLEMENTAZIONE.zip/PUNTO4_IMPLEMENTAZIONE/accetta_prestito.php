<?php

//VERIFICA CHE L'UTENTE SIA LOGGATO
session_start();
if(!isset($_SESSION['id_utente'])) {
    header("location: index.html");
    exit();
}
// VERIFICA CHE L'UTENTE SIA AMMINISTRATORE
if($_SESSION['flag'] != 0) {
    header("location: dashboard.php");
    exit();
}

// SE ENTRAMBE LE CONDIZIONI SONO SODDISFATTE ALLORA FA IL PROCESSO PER LA CONFERMA DEL PRESTITO
$id_prestito = $_POST["id_prestito"];
$id_libro = $_POST["id_libro"];

$conn = mysqli_connect("localhost", "root", "", "biblioteca");

// RECUPERA GIORNI RICHIESTI
$query = "SELECT * FROM prestiti WHERE id_prestito='$id_prestito';";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
$giorni_richiesti = $row['giorni_richiesti'];

// CALCOLA DATE
$data_inizio = date('Y-m-d');
$data_fine = date('Y-m-d', strtotime('+' . $giorni_richiesti . ' days'));

// AGGIORNA STATO PRESTITO E DATE
$query = "UPDATE prestiti SET stato='IN_PRESTITO', data_inizio='$data_inizio', data_fine='$data_fine' WHERE id_prestito='$id_prestito';";
mysqli_query($conn, $query);
$num = mysqli_affected_rows($conn);

if($num != 0) {
    echo "Prestito accettato con successo";
    header("refresh:2; url=richieste.php");
    exit();
} else {
    echo "Errore durante l'accettazione del prestito";
    header("refresh:2; url=richieste.php");
    exit();
}
?>
