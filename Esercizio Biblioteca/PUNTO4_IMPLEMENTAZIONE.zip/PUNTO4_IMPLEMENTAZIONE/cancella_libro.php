<?php
session_start();
//VERIFICA CHE L'UTENTE SIA LOGGATO
if(!isset($_SESSION['id_utente'])) {
    header("location: index.html");
    exit();
}
//VERIFICA CHE L'UTENTE SIA ADMIN
if($_SESSION['flag'] != 0) {
    header("location: dashboard.php");
    exit();
}
$id_libro = $_POST["id_libro"];

$conn = mysqli_connect("localhost", "root", "", "biblioteca");
$query = "DELETE FROM prestiti WHERE id_libro = $id_libro";
mysqli_query($conn, $query);
$query = "DELETE FROM libri WHERE id_libro='$id_libro';";
mysqli_query($conn, $query);
$num = mysqli_affected_rows($conn);

if($num != 0) {
    echo "Libro cancellato con successo";
    header("refresh:2; url=gestione_libri.php");
    exit();
} else {
    echo "Errore durante la cancellazione";
    header("refresh:2; url=gestione_libri.php");
    exit();
}
?>
