<?php
session_start();
//VERIFICA CHE L'UTENTE SIA LOGGATO
if(!isset($_SESSION['id_utente'])) {
    header("location: index.html");
    exit();
}
//VERIFICA CHE L'UTENTE SIA AMMINISTRATORE
if($_SESSION['flag'] != 0) {
    header("location: dashboard.php");
    exit();
}
$email = $_POST["email"];
$id_prestito = $_POST["id_prestito"];

$conn = mysqli_connect("localhost", "root", "", "biblioteca");

// RECUPERA DATI PRESTITO
$query = "SELECT prestiti.*, utenti.nome, utenti.cognome, libri.titolo FROM prestiti JOIN utenti ON prestiti.id_utente=utenti.id_utente JOIN libri ON prestiti.id_libro=libri.id_libro WHERE prestiti.id_prestito='$id_prestito';";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);

//SIMULAZIONE DI UN INVIO MAIL
$oggetto = "Sollecito restituzione libro";
$messaggio = "Gentile " . $row['nome'] . " " . $row['cognome'] . ",\n\n";
$messaggio .= "Le ricordiamo che il libro \"" . $row['titolo'] . "\" avrebbe dovuto essere restituito entro il " . $row['data_fine'] . ".\n\n";
$messaggio .= "La invitiamo a restituirlo il prima possibile.\n\n";
$messaggio .= "Cordiali saluti,\nLa Biblioteca";
$intestazioni = "From: biblioteca@biblioteca.it";

///NON FUNZIONA PERCHE' NON E' PRESENTE UN SERVER MAIL
//USO LA @ PERCHE' SERVE AD ESEGUIRE IL COMANDO MA A NON MOSTRARE IL WARNING SE E' PRESENTE
$inviata = @mail($email, $oggetto, $messaggio, $intestazioni);
$inviata=true; // SIMULO L'INVIO RIUSCITO
if($inviata) {
    echo "Mail di sollecito inviata con successo";
    header("refresh:2; url=prestiti_in_corso.php");
    exit();
} else {
    echo "Errore durante l'invio della mail";
    header("refresh:2; url=prestiti_in_corso.php");
    exit();
}
?>
