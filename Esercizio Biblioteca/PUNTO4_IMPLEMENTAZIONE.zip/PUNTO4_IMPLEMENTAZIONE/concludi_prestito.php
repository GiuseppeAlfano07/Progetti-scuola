<?php
session_start();
//VERIFICA CHE L'UTENTE SIA LOGGATO
if(!isset($_SESSION['id_utente'])) {
    header("location: index.html");
    exit();
}
//VERIFICA CHE L'UTENTE SIA LOGGATO
if($_SESSION['flag'] != 0) {
    header("location: dashboard.php");
    exit();
}
$id_prestito = $_POST["id_prestito"];
$id_libro = $_POST["id_libro"];
$data_restituzione = date('Y-m-d');

$conn = mysqli_connect("localhost", "root", "", "biblioteca");

// AGGIORNA STATO PRESTITO E DATA RESTITUZIONE
$query = "UPDATE prestiti SET stato='TERMINATO', data_restituzione='$data_restituzione' WHERE id_prestito='$id_prestito';";
mysqli_query($conn, $query);

// SEGNA IL LIBRO COME DISPONIBILE
$query = "UPDATE libri SET disponibile='SI' WHERE id_libro='$id_libro';";
mysqli_query($conn, $query);
$num = mysqli_affected_rows($conn);

if($num != 0) {
    echo "Libro restituito con successo";
    header("refresh:2; url=prestiti_in_corso.php");
    exit();
} else {
    echo "Errore durante la restituzione";
    header("refresh:2; url=prestiti_in_corso.php");
    exit();
}
?>
