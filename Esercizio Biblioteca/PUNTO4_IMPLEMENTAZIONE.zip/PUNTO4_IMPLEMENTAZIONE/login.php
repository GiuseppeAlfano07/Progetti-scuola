<?php
//LOGIN CON PASSWORD VERIFY
session_start();
$user = $_POST["user"];
$pw = $_POST["pw"];

$conn = mysqli_connect("localhost", "root", "", "biblioteca");
$query = "SELECT * FROM utenti WHERE username='$user';";
$result = mysqli_query($conn, $query);
$num = mysqli_num_rows($result);
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);

if($num != 0 && password_verify($pw, $row['password'])) {
    $_SESSION['username'] = $user;
    $_SESSION['id_utente'] = $row['id_utente'];
    $_SESSION['flag'] = $row['flag'];
    header("location: dashboard.php");
    exit();
} else {
    echo "Credenziali errate";
    header("refresh:2; url=index.html");
    exit();
}
?>
