<?php
$nome = $_POST["nome"];
$cognome = $_POST["cognome"];
$cf = $_POST["cf"];
$email = $_POST["email"];
$user = $_POST["user"];
$pw = password_hash($_POST["pw"], PASSWORD_DEFAULT);

$conn = mysqli_connect("localhost", "root", "", "biblioteca");
$query = "INSERT INTO utenti (nome, cognome, cf, email, username, password) VALUES ('$nome','$cognome','$cf','$email','$user','$pw');";
$result = mysqli_query($conn, $query);
header("location: index.html");
exit();
?>
